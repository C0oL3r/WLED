# DRL Usermod Rewrite Plan

The desync and delay you experienced with the software approach in the past was **not** because the ESP32 is too slow. It was because the old `handleButton` code relied on WLED's `shortPressAction(b)`, which executes WLED Presets via the JSON API. Parsing JSON and applying presets takes between 50ms and 100ms. When triggering two presets (Left then Right), they execute sequentially, causing the visible desynchronization!

## Proposed Changes

We will rewrite `DRL.cpp` to eliminate all WLED Button Logic and Jason API calls, and instead use lightning-fast hardware polling directly in C++.

### 1. New Polling Logic in `DRL::loop()`
We will read `pinStanga` and `pinDreapta` directly using `digitalRead()` every few milliseconds.
```cpp
bool currentLeft = digitalRead(pinStanga) == HIGH;
bool currentRight = digitalRead(pinDreapta) == HIGH;
```

### 2. Zero-Delay Perfect Sync (Bypassing JSON Presets)
We will add `leftSegment` and `rightSegment` settings to your Usermod Configuration menu.
Instead of triggering a preset, when a pin goes HIGH, the C++ code will **directly command WLED's effect engine**:
```cpp
if(currentLeft && currentRight) {
    // Avarii - Trigger both instantly at the exact same millisecond
    strip.getSegment(leftSegment).markForReset();
    strip.getSegment(rightSegment).markForReset();
}
```
Because this happens in C++ memory in exactly the same loop execution tick (`millis()`), WLED will render both segments with **0 milliseconds variance**. They will be perfectly synced to each other, and perfectly synced to your car's physical relay.

### 3. Fast Cross-Segment Abort Logic
- [NEW] Add a function `abortSignalState(uint8_t targetSegId)` to the `DRL` class. This will:
  - Check if `targetSegId` is currently active (`isSignaling[targetSegId] == true`).
  - If it is, explicitly set `strip.getSegment(targetSegId).env.step = 3;` and call `strip.trigger()`.
  - This instantly skips Phase 1 (Wiping) and Phase 2 (Waiting) of the `wipe_once` effect cycle, forcefully transitioning the segment straight into Phase 3 (CCT Restore and Fade-In), which creates the OEM abort behavior when flipping stalks mid-cycle.
- [MODIFY] Call `abortSignalState(rightSegmentId)` when Left signal triggers, and `abortSignalState(leftSegmentId)` when Right signal triggers.

### 4. Cleaning up DRL.cpp
- [DELETE] Old `handleButton` and `handleButtonAAA` methods.
- [DELETE] Global button tracking variables (`buttonPressedBefore`, `buttonActionDone`).
- [NEW] Variables for `leftSegment` and `rightSegment` in the configuration.
- [MODIFY] `wipe_once` effect to be strictly controlled by the C++ trigger logic.

## Verification Plan
1. We will compile the new `DRL.cpp`.
2. Manual verification by User:
   - Go to Config -> Usermods. Set the pins for Left and Right.
   - Set the Segment IDs corresponding to your Left and Right LED strips (usually 0 and 1).
   - Apply 3.3V to both Left and Right pins simultaneously to test the Avarii (Hazards).
   - Verify visually that both segments light up at the exact same time without any delay between them.
