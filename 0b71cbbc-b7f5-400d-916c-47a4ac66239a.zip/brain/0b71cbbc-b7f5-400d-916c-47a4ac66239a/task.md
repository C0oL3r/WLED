# Rewrite DRL Usermod from scratch

## Steps
- [x] Read the user's old logic and identify the target segments, effects, and presets.
- [x] Implement a fast hardware-polling loop in `DRL::loop()` instead of WLED's button API.
- [x] Solve the simultaneous segment problem (WLED sync) by applying effects symmetrically at the exact same strip execution tick.
- [x] Verify compilation and ask for user testing.
- [x] Implement cross-segment cancellation: when switching left/right stalks, instantly abort the opposite side's wipe effect and force it to fade out.
- [ ] Debug SK6812 LED strip hardware/configuration issue.
